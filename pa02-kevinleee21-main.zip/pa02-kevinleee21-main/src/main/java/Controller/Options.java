package Controller;

public enum Options {
  HARD, EASY, SHOW, EXIT
}

