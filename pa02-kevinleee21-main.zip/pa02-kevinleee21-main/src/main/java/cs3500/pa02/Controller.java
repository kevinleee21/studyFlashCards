package cs3500.pa02;

import java.io.FileNotFoundException;
import java.io.IOException;

public interface Controller {
  void run() throws IOException;
}
