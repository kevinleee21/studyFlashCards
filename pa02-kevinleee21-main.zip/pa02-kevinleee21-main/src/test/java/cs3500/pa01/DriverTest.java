package cs3500.pa01;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class DriverTest {

  @Test
  public void fakeTest() {
    assertEquals(5, 5);
  }
}