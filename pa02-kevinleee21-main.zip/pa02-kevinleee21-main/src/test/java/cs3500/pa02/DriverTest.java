package cs3500.pa02;

/*
class DriverTest {
    @Test
    public void testMain() {
        String[] args = {"/Users/kevinslee/IdeaProjects/PA-01/Output/output.md", "filename", "output.md"};
        String content;
        try {
            Driver.main(args);
            content = new String(Files.readAllBytes(Paths.get("output.md")));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        System.out.println(content);
    }
}

 */
